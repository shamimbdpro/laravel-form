<?php $__env->startSection('content'); ?>

  <?php $__currentLoopData = $social_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form class="col-lg-6 col-lg-offset-4" action="<?php echo e(route('update_social')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <h5 style="text-align:center;color:green"><?php if(Session('smg')): ?>
      <?php echo e(Session('smg')); ?>

  <?php endif; ?> </h5>
  <div class="form-group row">
    <label for="google_plus" class="col-sm-2 col-form-label">Google Plus</label>
    <div class="col-sm-10">
      <input type="text" name="sm_google_plus" class="form-control" id="google_plus" value="<?php echo e($s_data->sm_google_plus); ?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="linkdin" class="col-sm-2 col-form-label">linkdin</label>
    <div class="col-sm-10">
      <input type="text" name="sm_linkdin" class="form-control" id="linkdin" placeholder="linkdin" value="<?php echo e($s_data->sm_linkdin); ?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="Printest" class="col-sm-2 col-form-label">Printest</label>
    <div class="col-sm-10">
      <input type="text" name="sm_printer" class="form-control" id="Printest" placeholder="Printest" value="<?php echo e($s_data->sm_printer); ?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="Dribbble" class="col-sm-2 col-form-label">Dribbble</label>
    <div class="col-sm-10">
      <input type="text" name="sm_dribble" class="form-control" id="Dribbble" placeholder="Dribbble" value="<?php echo e($s_data->sm_dribble); ?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="Twitter" class="col-sm-2 col-form-label">Twitter</label>
    <div class="col-sm-10">
      <input type="text" name="sm_twitter" class="form-control" id="Twitter" placeholder="Twitter" value="<?php echo e($s_data->sm_twitter); ?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="Facebook"  class="col-sm-2 col-form-label">Facebook</label>
    <div class="col-sm-10">
      <input type="text" name="sm_facebook" class="form-control" id="Facebook" placeholder="Facebook" value="<?php echo e($s_data->sm_facebook); ?>">
    </div>
  </div>

  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Sign in</button>
    </div>
  </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>