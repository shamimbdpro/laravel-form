;
<?php $__env->startSection('content'); ?>
<table id="table_id" class="display" style="background:#FFF;border:2px solid #ccc">
  <thead>
    <tr>
      <th>Contact id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Subject</th>
      <th>Message</th>
      <th>Time</th>
      <th>Manage</th>
    </tr>
  </thead>
    <tbody >
      <?php $__currentLoopData = $recycle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Recycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th><?php echo e($Recycle->contactId); ?></th>
        <td><?php echo e($Recycle->contactname); ?></td>
        <td><?php echo e($Recycle->contactemail); ?></td>
        <td><?php echo e($Recycle->contactsubject); ?></td>
        <td><?php echo e(str_limit($Recycle->contactmessage,50)); ?></td>
        <td><?php echo e($Recycle->created_at); ?></td>
        <td>
          <a class="btn btn-primary"  onclick="return confirm('are you sure delete data')"  href="<?php echo e(route('restore', $Recycle->contactId)); ?>">Restore</i></a>
          <a class="btn btn-danger" onclick="return confirm('are you sure delete data')" href="<?php echo e(route('delete',$Recycle->contactId)); ?>">Delete</i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>