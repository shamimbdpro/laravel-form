  	  
  	  <?php $__env->startSection('content'); ?>

  	  <div class="container">
  	  	 <div class="row justify-content-lg-center">
  	  	 	<div class="col-lg-8 contact-form">
	   <form>
	   	<?php echo csrf_field(); ?>
		  <div class="form-group">
		    <label for="name">Name</label>
		    <input type="text" class="form-control" id="name" placeholder="Enter your name">
		  </div>
		  <div class="form-group">
		    <label for="Username">Username</label>
		    <input type="text" class="form-control" id="Username" placeholder="Enter your Username">
		  </div>
		   <div class="form-group">
		    <label for="Email">Email</label>
		    <input type="email" class="form-control" id="Email" placeholder="Enter your email">
		  </div>
		   <div class="form-group">
		    <label for="password">Password</label>
		    <input type="password" class="form-control" id="passowrd" placeholder="Enter your password">
		  </div>
		   <div class="form-group">
		    <label for="re_pass">Confirm Password</label>
		    <input type="password" class="form-control" id="re_pass" placeholder="Confirm Password">
		  </div>
		  <div class="form-group">
		    <label for="roll">Roll</label>
		    <input type="text" class="form-control" id="roll" placeholder="Enter your roll">
		  </div>
		  <div>
		  	 Select your gender &nbsp;&nbsp;
		     Male <input type="radio" name="gander">&nbsp;&nbsp;
		      Female <input type="radio" name="gander">&nbsp;&nbsp
		     Other <input type="radio" name="gander">&nbsp;&nbsp;
		  </div>
		   <div>
		  	 Select your subject &nbsp;&nbsp;
		     Male <input type="checkbox" name="gander">&nbsp;&nbsp;
		      Female <input type="checkbox" name="gander">&nbsp;&nbsp
		     Other <input type="checkbox" name="gander">&nbsp;&nbsp;
		  </div>
		  <div class="">
		  	 Select your country
		  	 <select>
		  	 	<option>Bangladesh</option>
		  	 	<option>Pakistan</option>
		  	 	<option>India</option>
		  	 	<option>England</option>
		  	 </select>
		  </div>
            <input  type="submit" class="form-control btn-primary" value="Register" name="Register">
		</form>
	  </div>
	    </div>
     </div>

     <?php $__env->stopSection(); ?>;
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>