;
<?php $__env->startSection('content'); ?>
<div class="text-right">
<a  href="<?php echo e(route('show-banner')); ?>" class="btn btn-success">Add Banner</a>
</div>
<table class="table table-bordered" style="background:#FFF">
  <thead>
    <tr>
      <th scope="col">Banner ID</th>
      <th scope="col">Title</th>
      <th scope="col">Subtitle</th>
      <th scope="col">Status</th>
      <th scope="col">Time</th>
      <th scope="col">Photo</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($ban->ban_id); ?></th>
      <td><?php echo e(str_limit($ban->ban_title,20)); ?></td>
      <td><?php echo e(str_limit($ban->ban_subtitle,20)); ?></td>
      <td><?php echo e($ban->ban_status); ?></td>
      <td><?php echo e($ban->created_at); ?></td>
      <td>
        <img height="50" src="public/uploads/<?php echo e($ban->ban_photo); ?>" alt="">
      </td>
      <td>
        <a href="" class="btn btn-primary">View</a>
        <a href="" class="btn btn-warning">Edit</a>
        <a href="" class="btn btn-danger">Trash</a>
      </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>