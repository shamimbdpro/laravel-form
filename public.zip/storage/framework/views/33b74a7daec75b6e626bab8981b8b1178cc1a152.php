<?php $__env->startSection('content'); ?>
<div class="text-right">
<a  href="<?php echo e(route('all-banner')); ?>" class="btn btn-success">All Banner</a>
</div>
<div class="banner_add" style="background:#FFF;padding:20px">
  <h5 style="text-align:center;color:green"><?php if(Session('smg')): ?>
      <?php echo e(Session('smg')); ?>

  <?php endif; ?> </h5>
<form action="<?php echo e(route('add-banner')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="form-group <?php echo e($errors->has('ban-title') ? 'has-error' : ''); ?>">
    <label for="title">Banner title</label>
    <input type="text" class="form-control" name="ban-title" id="title" >
    <?php if($errors->has('ban-title')): ?>
           <span class='help-block'>
                 <?php echo e($errors->first('ban-title')); ?>

           </span>
    <?php endif; ?>
  </div>
  <div class="form-group">
    <label for="subtitle">Banner Subtitle</label>
    <input type="text" class="form-control" name="ban-subtitle" id="subtitle">
  </div>
  <div class="form-group">
    <label for="ban_button">Banner Button</label>
    <input type="text" class="form-control" name="ban-btn" id="ban_button">
  </div>
  <div class="form-group">
    <label for="btn_url">Banner Button Url</label>
    <input type="text" class="form-control" name="ban-url" id="btn_url">
  </div>
  <div class="form-group">
    <label for="ban_photo">Banner Photo</label>
    <input type="file" class="form-control" name="ban-photo" id="ban_photo">
  </div>
  <div class="submit" style="text-align:center">
     <input type="submit" class="btn btn-primary" name="submit" value="Submit">
  </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>