;
<?php $__env->startSection('content'); ?>
<?php if(Session('trash')): ?>
    <div class="alert alert-warning">
        <?php echo e(session('trash')); ?>

    </div>
<?php endif; ?>
<table id="table_id" class="display" style="background:#FFF;border:2px solid #ccc">
  <thead>
    <tr>
      <th>Contact id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Subject</th>
      <th>Message</th>
      <th>Time</th>
      <th>Manage</th>
    </tr>
  </thead>
    <tbody >
      <?php $__currentLoopData = $contactus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th><?php echo e($contact->contactId); ?></th>
        <td><?php echo e($contact->contactname); ?></td>
        <td><?php echo e($contact->contactemail); ?></td>
        <td><?php echo e($contact->contactsubject); ?></td>
        <td><?php echo e(str_limit($contact->contactmessage,50)); ?></td>
        <td><?php echo e($contact->created_at); ?></td>
        <td>
          <a href="<?php echo e(route('contactview', $contact->contactId)); ?>"><i class="fa fa-plus-square fa-lg"></i></a>
          <a href=""><i class="fa fa-pencil-square fa-lg"></i></a>
          <?php if(Auth::User()->role_id<=1): ?>
           <a href="<?php echo e(route('trash',$contact->contactId)); ?>"><i class="fa fa-trash fa-lg"></i></a>
         <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>