;
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<table class="table table-bordered" style="background:#FFF">
  <thead>
    <tr>
      <th scope="col">Banner ID</th>
      <th scope="col">Title</th>
      <th scope="col">Subtitle</th>
      <th scope="col">Status</th>
      <th scope="col">Time</th>
      <th scope="col">Photo</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $recycle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($ban->ban_id); ?></th>
      <td><?php echo e(str_limit($ban->ban_title,20)); ?></td>
      <td><?php echo e(str_limit($ban->ban_subtitle,20)); ?></td>
      <td><?php echo e($ban->ban_status); ?></td>
      <td><?php echo e($ban->created_at); ?></td>
      <td>
        <img height="50" src="public/uploads/<?php echo e($ban->ban_photo); ?>" alt="">
      </td>
      <td>
       <a class="btn btn-primary" href="<?php echo e(route('ban_restore', $ban->ban_id)); ?>">Restore</i></a>
          <a class="btn btn-danger" onclick="return confirm('are you sure delete data')" href="<?php echo e(route('ban_delete',$ban->ban_id)); ?>">Delete</i></a>
   
      </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>