<?php $__env->startSection('content'); ?>
<section class="page-title bg-2">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block">
          <h1>Drop Us A Note</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi, quibusdam.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php if(Session('error')): ?>
  <script type="text/javascript">
  swal(
    'Opps!!',
    'Please try again!',
    'success',
    )
  </script>
<?php endif; ?>
<!-- contact form start -->
<section class="contact-form">
    <div class="container">
        <div class="row">
          <?php if(Session('status')): ?>
          <script type="text/javascript">
          swal(
            'Success!',
            'Thanks for contact with us!',
            'success',
            )
          </script>
          <?php endif; ?>
            <form action="<?php echo e(route('insert')); ?>" method="post">
               <?php echo csrf_field(); ?>
                <div class="col-md-6 col-sm-12">
                    <div class="block">

                        <div class="form-group <?php echo e($errors->has('user_name') ? 'has-error' : ''); ?>">
                            <input name="user_name" type="text" class="form-control has->error" value="<?php echo e(old('user_name')); ?>" placeholder="Your Name">
                        <?php if($errors->has('user_name')): ?>
                               <span class='help-block'>
                                     <?php echo e($errors->first('user_name')); ?>

                               </span>
                        <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('user_email') ? 'has-error' : ''); ?>">
                            <input name="user_email" type="text" class="form-control" value="<?php echo e(old('user_email')); ?>" placeholder="Email Address">
                            <?php if($errors->has('user_email')): ?>
                                   <span class='help-block'>
                                         <?php echo e($errors->first('user_email')); ?>

                                   </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('user_subject') ? 'has-error' : ''); ?>">
                            <input name="user_subject" type="text" class="form-control" value="<?php echo e(old('user_subject')); ?>" placeholder="Subject">
                            <?php if($errors->has('user_subject')): ?>
                                   <span class='help-block'>
                                         <?php echo e($errors->first('user_subject')); ?>

                                   </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="block">
                        <div class="form-group-2 <?php echo e($errors->has('user_message') ? 'has-error' : ''); ?>">
                            <textarea name="user_message" class="form-control" rows="3" placeholder="Your Message"><?php echo e(old('user_message')); ?></textarea>
                             <?php if($errors->has('user_message')): ?>
                                   <span class='help-block'>
                                         <?php echo e($errors->first('user_message')); ?>

                                   </span>
                             <?php endif; ?>
                        </div>
                            <button class="btn btn-default" type="submit">Send Message</button>
                    </div>
                </div>
                <div class="error" id="error">Sorry Msg dose not sent</div>
                <div class="success" id="success">Message Sent</div>
            </form>
        </div>
        <div class=" contact-box row">
            <div class="col-md-6 col-sm-12">
                <div class="block">
                    <h2>Stop By For A visit</h2>
                    <ul class="address-block">
                        <li>
                            <i class="ion-ios-location-outline"></i>North Main Street,Brooklyn Australia
                        </li>
                        <li>
                            <i class="ion-ios-email-outline"></i>Email: contact@mail.com
                        </li>
                        <li>
                            <i class="ion-ios-telephone-outline"></i>Phone:+88 01672 506 744
                        </li>
                    </ul>
                    <ul class="social-icons">
                      <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>
                          <a href="<?php echo e($value->sm_facebook); ?>"><i class="ion-social-googleplus-outline"></i></a>
                      </li>
                      <li>
                          <a href="<?php echo e($value->sm_linkdin); ?>"><i class="ion-social-linkedin-outline"></i></a>
                      </li>
                      <li>
                          <a href="<?php echo e($value->sm_printer); ?>"><i class="ion-social-pinterest-outline"></i></a>
                      </li>
                      <li>
                          <a href="<?php echo e($value->sm_dribbble); ?>"><i class="ion-social-dribbble-outline"></i></a>
                      </li>
                      <li>
                          <a href="<?php echo e($value->sm_twitter); ?>"><i class="ion-social-twitter-outline"></i></a>
                      </li>
                      <li>
                          <a href="<?php echo e($value->sm_facebook); ?>"><i class="ion-social-facebook-outline"></i></a>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="block">
                    <h2>We Also Count In Google Map</h2>
                    <div class="google-map">
                        <div id="map"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>