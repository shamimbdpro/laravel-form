;
<?php $__env->startSection('content'); ?>
<table id="table_id" class="display" style="background:#FFF;border:2px solid #ccc">
  <thead>
    <tr>
      <th>UserId</th>
      <th>Name</th>
      <th>User Role</th>
      <th>Email</th>
      <th>Status</th>
      <th>Time</th>
      <th>Manage</th>
    </tr>
  </thead>
    <tbody >
      <?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th><?php echo e($user->id); ?></th>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->roleName->role_name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td>
         <?php if($user->status==1): ?>
           <a href="<?php echo e(route('Enactive',$user->id)); ?>" class="btn btn-primary">Active</a>
           <?php else: ?>
             <a href="<?php echo e(route('active',$user->id)); ?>" class="btn btn-danger">Deactive</a>
         <?php endif; ?>
        </td>
        <td><?php echo e($user->created_at); ?></td>
        <td>
          <a href=""><i class="fa fa-plus-square fa-lg"></i></a>
          <a href=""><i class="fa fa-pencil-square fa-lg"></i></a>
          <a href=""><i class="fa fa-trash fa-lg"></i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>